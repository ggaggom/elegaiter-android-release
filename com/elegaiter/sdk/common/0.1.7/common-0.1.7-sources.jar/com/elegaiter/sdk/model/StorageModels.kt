package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable
/**
 * 운동 설정 정보를 담는 데이터 클래스 (DataStore에 저장)
 */
@Serializable // DataStore에 JSON 문자열로 저장하기 위해 추가
data class ExerciseInfo(
    val speed: Float = 0f,
    val incline: Float = 0f,
    val duration: Int = 0,
    val indexFoot: String = "left",
    val autoSave: Boolean = false,
    val mood: String = "",
    val exerciseMode: ExerciseMode
)

/**
 * 파일로 저장된 운동 세션의 요약 정보를 담는 데이터 클래스
 */
data class SessionInfo(
    val fileName: String,      // "step_stats_20250813_1.json"
    val date: String,
    val session: Int,
    val elapsedTime: Long,
)