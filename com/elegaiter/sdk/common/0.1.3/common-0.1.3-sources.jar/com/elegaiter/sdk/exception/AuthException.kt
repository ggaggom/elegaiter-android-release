package com.elegaiter.sdk.exception

/**
 * SDK 공통 인증 예외 클래스
 */
sealed class AuthException(message: String) : Exception(message) {
    // 1단계 힌트 불일치
    /** 비밀번호 찾기 1단계 힌트 불일치 */
    class InvalidHintException : AuthException("The hint and answer do not match.")

    /** 비밀번호 찾기 2단계 토큰 만료 */
    class TokenExpiredException : AuthException("The reset token has expired.")
}