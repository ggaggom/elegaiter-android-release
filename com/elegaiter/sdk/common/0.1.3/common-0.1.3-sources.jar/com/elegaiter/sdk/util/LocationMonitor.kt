package com.elegaiter.sdk.util

import kotlinx.coroutines.flow.Flow

interface LocationMonitor {
    val isGranted: Flow<Boolean>
    val isGpsOn: Flow<Boolean>
}
