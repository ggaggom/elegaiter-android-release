package com.elegaiter.sdk.model

/**
 * Median, IQR그래프용 데이터
 */
data class Stats(val median: Double, val iqr: Double)
