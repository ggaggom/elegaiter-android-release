package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

@Serializable
enum class StepType(val korean: String) {
    WALK("걷기"), 
    RUN("뛰기"), 
    UNKNOWN("알 수 없음"), 
    NONE("없음")
}