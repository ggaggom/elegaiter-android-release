package com.elegaiter.sdk

import com.elegaiter.sdk.manager.AuthManager
import com.elegaiter.sdk.manager.BleManager
import com.elegaiter.sdk.manager.GaitAnalysisManager
import com.elegaiter.sdk.manager.GaitRecordManager

/**
 * Elegaiter SDK의 모든 기능에 접근하기 위한 메인 인터페이스.
 * 앱 개발자는 이 인터페이스의 인스턴스 하나만으로 모든 기능을 사용할 수 있습니다.
 */
interface ElegaiterSdk {
    /** BLE 연결 관련 기능을 담당합니다. */
    val bleManager: BleManager

    /** 사용자 인증(로그인/회원가입) 등 계정 관련 기능을 담당합니다. */
    val authManager: AuthManager

    /** 보행 데이터 분석에 대한 전반적인 정보를 제공합니다. */
    val gaitAnalysisManager: GaitAnalysisManager

    /** 보행 데이터 기록을 관리하고 서버로 전송합니다.  */
    val gaitRecordManager: GaitRecordManager

}
