package com.elegaiter.sdk.model

/**
 * 조회된 사용자 프로필 정보
 */
data class UserProfile(
    val name: String,
    val gender: String,
    val birthday: String, // "YYYY-MM-DD"
    val phone: String,
    val height: Float,
    val weight: Float,
    val pw: String? = null // 나중에 삭제
)