package com.elegaiter.sdk.model

/**
 * 회원가입 시 필요한 사용자 정보
 */
data class NewUserInfo(
    val id: String,
    val pass: String,
    val pwhint: String,
    val pwhintAns: String,
    val name: String,
    val gender: String,
    val birthday: String, // "YYYY-MM-DD"
    val phone: String,
    val height: Float,
    val weight: Float
)