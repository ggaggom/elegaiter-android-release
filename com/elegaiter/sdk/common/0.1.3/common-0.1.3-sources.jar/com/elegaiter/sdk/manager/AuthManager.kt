package com.elegaiter.sdk.manager

import com.elegaiter.sdk.model.ExerciseInfo
import com.elegaiter.sdk.model.Result
import com.elegaiter.sdk.model.NewUserInfo
import com.elegaiter.sdk.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 사용자 계정(인증, 정보 관리 등)에 관련된 모든 기능을 담당합니다.
 */
interface AuthManager {
    /** 현재 로그인된 사용자 ID. 비로그인 시 null. */
    val currentUserId: StateFlow<String?>

    /** 저장된 운동 설정 정보의 변경 사항을 감지하는 Flow */
    val savedExerciseInfo: Flow<ExerciseInfo?>

    /** 세션(리프레시 토큰) 만료 이벤트를 방출하는 Flow. UI에서 관찰하여 로그인 화면으로 이동합니다. */
    val sessionExpiredEvent: SharedFlow<Unit>

    /**
     * 현재 세션(토큰)이 유효한지 확인하고 자동 로그인을 결정합니다.
     * 내부적으로 프로필 조회 등을 시도하며, 토큰 만료 시 자동으로 갱신을 시도합니다.
     * *  @return [Result.Success]이며 데이터가 true인 경우 자동 로그인이 가능하므로 메인 화면으로 이동하고,
     * * false인 경우 세션이 만료되었거나 정보가 없으므로 로그인 화면으로 이동해야 합니다.
     */
    suspend fun checkAuthStatus(): Result<Boolean>

    /** 회원가입 시 아이디 사용 가능 여부를 확인합니다. */
    suspend fun checkIdAvailability(id: String): Result<Boolean>

    /** 새로운 사용자를 등록(회원가입)합니다. */
    suspend fun register(info: NewUserInfo): Result<Unit>

    /** 사용자를 로그인시킵니다. */
    suspend fun login(id: String, password: String, isAutoLogin: Boolean): Result<Unit>

    /** 현재 사용자를 로그아웃시킵니다. */
    suspend fun logout()

    /** 이름과 전화번호로 아이디를 찾습니다. */
    suspend fun findId(name: String, phone: String): Result<String?>

    /** 비밀번호 찾기 1단계: 가입 시 등록한 힌트와 답변을 확인합니다.
     * * @return 힌트 확인 성공 시, 5분간 유효한 비밀번호 재설정용 토큰(String) 반환
     * * @return [Result.Error] 힌트나 답변이 일치하지 않을 경우 [AuthException.InvalidHintException] 반환
     */
    suspend fun verifyPasswordHint(id: String, hint: String, answer: String): Result<String>

    /** 비밀번호 찾기 2단계: 힌트 확인 후, 새로운 비밀번호로 재설정합니다.
     * * @param token [verifyPasswordHint] 단계에서 성공적으로 반환받은 재설정 전용 토큰
     * * @return [Result.Error] 토큰이 만료된 경우 [AuthException.TokenExpiredException] 반환
     */
    suspend fun resetLostPassword(newPassword: String, token: String): Result<Unit>

    /** 현재 로그인된 사용자의 전체 프로필 정보를 가져옵니다. */
    suspend fun getUserProfile(): Result<UserProfile>

    /** 현재 로그인된 사용자의 프로필 정보를 업데이트합니다. */
    suspend fun updateUserProfile(updatedProfile: UserProfile): Result<Unit>

    /** 현재 로그인된 사용자의 비밀번호를 변경합니다. (기존 비밀번호 확인 필요) */
    suspend fun changePassword(currentPassword: String, newPassword: String): Result<Unit>

    /** 회원에서 탈퇴합니다. (비밀번호 확인 필요) */
    suspend fun deleteAccount(password: String): Result<Unit>

    /** 운동 설정 정보를 저장합니다. */
    suspend fun saveExerciseInfo(info: ExerciseInfo)

    /** 현재 로그인된 사용자의 비밀번호가 일치하는지(재인증) 확인합니다. */
    suspend fun verifyCurrentPassword(password: String): Result<Unit>

}