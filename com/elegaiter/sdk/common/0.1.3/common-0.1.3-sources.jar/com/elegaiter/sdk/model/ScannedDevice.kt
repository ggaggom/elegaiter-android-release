package com.elegaiter.sdk.model

/** 스캔된 BLE 장치의 정보를 담는 데이터 클래스 **/
data class ScannedDevice(
    val name: String,
    val address: String
)