package com.elegaiter.sdk.model

enum class BleConnectionState { CONNECTED, DISCONNECTED, CONNECTING, ERROR }