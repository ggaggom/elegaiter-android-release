package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

/**
 * 걸음 종류별 통계 (걷기, 뛰기, 절뚝임)
 */
@Serializable
data class StepTypeStatistics(
    val walking: PerGaitTypeStat,
    val running: PerGaitTypeStat,
    val limping: PerGaitTypeStat
)

@Serializable
data class PerGaitTypeStat(
    val count: Int,
    val ratio: Double,
    val totalDurationS: Double
)