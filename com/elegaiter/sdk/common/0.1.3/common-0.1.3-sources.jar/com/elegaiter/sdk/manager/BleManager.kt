package com.elegaiter.sdk.manager

import com.elegaiter.sdk.model.BleConnectionState
import com.elegaiter.sdk.model.ScannedDevice
import com.elegaiter.sdk.model.Result
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * JAWS 센서와의 BLE 연결을 담당합니다.
 */
interface BleManager {
    /** 현재 연결 상태를 실시간으로 확인할 수 있습니다. */
    val connectionState: StateFlow<BleConnectionState>

    /** 장치로부터 Threshold 응답을 수신하면 알려줍니다. */
    val thresholdResponse: SharedFlow<Int>

    /** 현재 Threshold 값을 확인하는 명령을 전송합니다. */
    suspend fun checkThreshold(): Result<Unit>

    /** 주변의 Elegaiter 장비를 스캔합니다. */
    suspend fun scan(): Result<List<ScannedDevice>>

    /**
     * 특정 장비에 연결을 시도합니다.
     * 이전에 연결했던 장비가 있다면 자동으로 연결을 시도할 수도 있습니다.
     */
    suspend fun connect(device: ScannedDevice): Result<Unit>

    /** 현재 연결을 해제합니다. */
    fun disconnect()

    /**
     * Threshold 값을 수동으로 설정하는 명령을 전송합니다.
     * @param level 설정할 레벨 값
     */
    suspend fun setThreshold(level: Int): Result<Unit>

    /**
     * Threshold 값을 자동으로 설정하는 명령을 전송합니다.
     */
    suspend fun setAutoThreshold(): Result<Unit>

    /**
     * 에러 코드를 전송합니다.
     * @param errorCode 전송할 에러 코드 (0 또는 1)
     */
    suspend fun sendError(errorCode: Int): Result<Unit>
}