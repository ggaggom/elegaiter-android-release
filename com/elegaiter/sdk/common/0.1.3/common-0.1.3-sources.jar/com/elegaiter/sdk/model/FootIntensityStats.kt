package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

/**
 * 좌/우 발 강도 통계
 */
@Serializable
data class FootIntensityStats(
    val left: IntensityStat,
    val right: IntensityStat
)

/**
 * 좌/우 보폭 시간 통계
 * 보폭 시간은 한 발이 땅에 닿은 후 반대 발이 땅에 닿기까지의 시간입니다.
 * 보행의 리듬과 규칙성을 분석하는 데 사용됩니다.
 */
@Serializable
data class StepDurationStats(
    val left: DurationStat,
    val right: DurationStat
)

/**
 * 좌/우 발 활보 시간 통계
 * 활보 시간은 한 발이 땅에 닿은 후 다시 '같은 발'이 땅에 닿기까지의 시간입니다.
 */
@Serializable
data class StrideDurationStats(
    val left: DurationStat,
    val right: DurationStat
)

/**
 * 강도(Intensity)에 대한 상세 통계 데이터
 */
@Serializable
data class IntensityStat(
    val count: Int, // 걸음 수
    val average: Double, //평균값
    val stdDev: Double, // 표준편차
    val median: Double, // 중간값
    val iqr: Double, // IQR
    val peakPosition: Int // 압력 최고점의 평균 위치
)

/**
 * 시간(Duration)에 대한 상세 통계 데이터
 */
@Serializable
data class DurationStat(
    val averageS: Double, // 평균값
    val stdDevS: Double, // 표준편차
    val medianS: Double, // 중간값
    val iqrS: Double, // IQR
)