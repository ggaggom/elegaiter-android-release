package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

/**
 * 운동 모드
 */
@Serializable
enum class ExerciseMode {
    INDEX, // 인덱스 워킹
    STATIC, // 표준 보행 분석
    GAME,      // 게임
    FITNESS  // 피트니스 코칭
}

/**
 * 구간 정보
 */
@Serializable
data class SessionSegment(
    val startTime: Long,
    var endTime: Long? = null,
    val mode: ExerciseMode
)