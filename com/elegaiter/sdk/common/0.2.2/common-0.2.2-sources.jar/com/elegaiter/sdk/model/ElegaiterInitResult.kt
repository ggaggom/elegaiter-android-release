package com.elegaiter.sdk.model

/**
 * SDK 초기화 결과 상태 코드
 */
enum class ElegaiterInitResult {
    SUCCESS,                // 초기화 성공
    NETWORK_ERROR,          // 네트워크 연결 불량 (재시도 권장)
    SERVER_ERROR,           // 서버 응답 오류 (잠시 후 시도 권장)
    INVALID_LICENSE,        // 잘못된 라이선스
}