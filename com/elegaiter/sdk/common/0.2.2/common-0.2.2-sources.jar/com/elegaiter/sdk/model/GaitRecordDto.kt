package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

@Serializable
data class GaitRecordDto(
    val fileName: String,
    val userId: String,
    val date: String,
    val sessionCount: Int,
    val exerciseInfo: ExerciseInfo,
    val elapsedTime: Long,
    val extraMetadata: String? = null
)