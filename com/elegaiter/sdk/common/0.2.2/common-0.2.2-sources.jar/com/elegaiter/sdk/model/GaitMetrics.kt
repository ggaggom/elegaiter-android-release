package com.elegaiter.sdk.model

import kotlinx.serialization.Serializable

/**
 * 사용자의 보행 특징을 다각도로 요약한 핵심 데이터 모델
 */
@Serializable
data class GaitMetrics(
    /** 측정된 총 걸음 수 */
    val totalSteps: Int,

    /** 분당 걸음 수, 즉 보행의 속도 (cadence) */
    val cadence: Int,

    /** 전체 보행 신호의 중심 경향을 나타내는 중앙값 */
    val overallMedian: Double,

    /** 전체 보행 신호의 안정성(흩어짐 정도)을 나타내는 사분위수 범위 */
    val overallIqr: Double,

    /** 걷기/뛰기 등 보행 유형별 통계 (횟수, 비율, 시간) */
    val stepTypeStats: StepTypeStatistics,

    /** 좌우 발의 상대적 강도 비교를 통한 보행 균형 통계 */
    val footIntensity: FootIntensityStats,

    /** 보폭 시간(한 발→다음 발)의 평균과 안정성을 나타내는 리듬 통계 */
    val stepDuration: StepDurationStats,

    /** 활보 시간(한 발→같은 발)의 평균과 안정성을 나타내는 대칭성 통계 */
    val strideDuration: StrideDurationStats,

    /** 가장 최근에 감지된 걸음의 종류 (걷기, 뛰기, 불명확 등) */
    val lastStepType: StepType = StepType.NONE,

    /** 최종 좌측 발 Median 그래프 데이터 */
    val leftMedianData: List<Float> = emptyList(),

    /** 최종 좌측 발 IQR 그래프 데이터 */
    val leftIqrData: List<Float> = emptyList(),

    /** 최종 우측 발 Median 그래프 데이터 */
    val rightMedianData: List<Float> = emptyList(),

    /** 최종 우측 발 IQR 그래프 데이터 */
    val rightIqrData: List<Float> = emptyList(),

    /**  전체 운동 Raw envelope 데이터 (서버 전송용) */
    val fullEnvelopeHistory: List<Int> = emptyList(),

    /** 보폭 길이 (cm). speed × strideDuration으로 계산 */
    val stepLength: Double = 0.0,
)
