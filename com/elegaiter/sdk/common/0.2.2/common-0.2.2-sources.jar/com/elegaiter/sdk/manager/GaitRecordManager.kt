package com.elegaiter.sdk.manager

import com.elegaiter.sdk.model.ExerciseInfo
import com.elegaiter.sdk.model.GaitMetrics
import com.elegaiter.sdk.model.GaitRecordDto
import com.elegaiter.sdk.model.Result
import com.elegaiter.sdk.model.SessionInfo
import com.elegaiter.sdk.model.SessionSegment

interface GaitRecordManager {

    /**
     * 분석 데이터를 받아 로컬에 저장하고 서버 전송을 시도합니다.
     */
    suspend fun recordAndSyncGait(
        metrics: GaitMetrics,
        exerciseInfo: ExerciseInfo,
        userId: String,
        date: String,
        sessionCount: Int,
        elapsedTime: Long,
        sessionSegments: List<SessionSegment>? = emptyList(),
        description: String? = null,
        extraMetadata: String? = null
    ): Result<GaitRecordDto>

    /**
     * 전송에 실패하여 로컬에 남아있는 모든 데이터를 다시 전송합니다.
     * @return 성공적으로 동기화된 개수를 담은 Result.Success, 또는 작업 자체에 에러 발생 시 Result.Error
     */
    suspend fun syncPendingRecords(): Result<Int> // 성공한 개수 반환


    /**
     * 파일 이름으로 저장된 운동 세션을 삭제합니다.
     * @param fileName 삭제할 파일의 이름
     */
    suspend fun deleteRecord(fileName: String): Result<Unit>

    /**
     * 저장된 모든 운동 기록 목록을 불러옵니다.
     */
    suspend fun listRecords(): Result<List<SessionInfo>>

    /**
     * 파일 이름으로 특정 운동 기록의 상세 데이터를 불러옵니다.
     */
    suspend fun loadRecord(fileName: String): Result<GaitMetrics?>

    /**
     * 파일 이름으로 특정 운동 기록의 메타 데이터를 불러옵니다.
     */
    suspend fun loadRecordMetaData(fileName: String): Result<GaitRecordDto?>

    /**
     * 특정 운동 기록을 웹 대시보드에서 상세 보기 위한 전체 URL을 생성합니다.
     * @return [Result.Success] 시 웹 대시보드로 즉시 연결 가능한 URL 문자열을 반환합니다.
     * @exception GaitException.RecordNotFoundException 해당 파일 이름의 기록이 로컬 DB에 없을 경우.
     * @exception GaitException.NotSyncedException 해당 기록이 아직 서버로 업로드되지 않아 웹 리포트 생성이 불가능할 경우.
     * @exception GaitException.WebAuthTokenException 인증 서버와의 통신 실패로 임시 토큰을 발급받지 못했을 경우.
     */
    suspend fun getDashboardUrl(fileName: String): Result<String>
}