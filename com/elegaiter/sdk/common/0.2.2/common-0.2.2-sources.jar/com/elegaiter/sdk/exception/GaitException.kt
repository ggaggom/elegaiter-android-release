package com.elegaiter.sdk.exception

/**
 * 보행 데이터 관리 및 동기화 관련 예외 클래스
 */
sealed class GaitException(message: String): Exception(message) {
    /** 로컬에서 해당 파일을 찾을 수 없는 경우 */
    class RecordNotFoundException : GaitException("Record not found for the given file name.")

    /** 서버에 동기화(가 되지 않은 상태에서 웹 뷰를 요청한 경우 */
    class NotSyncedException : GaitException("This record has not been synced to the server yet.")

    /** 웹 대시보드 접근용 임시 토큰 발급에 실패한 경우 */
    class WebAuthTokenException(cause: Throwable?) : GaitException("Failed to issue web authentication token.")
}