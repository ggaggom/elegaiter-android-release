package com.elegaiter.sdk.manager

import com.elegaiter.sdk.model.ExerciseInfo
import com.elegaiter.sdk.model.GaitMetrics
import com.elegaiter.sdk.model.Stats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 보행 데이터의 '통계 분석' 결과를 실시간으로 제공합니다.
 * (예: 걸음 수, 케이던스, 좌우 강도 등 숫자 데이터)
 */
interface GaitAnalysisManager {
    /**
     * 실시간 보행 분석 통계 데이터 스트림.
     * UI는 이 Flow를 구독하여 각종 수치를 화면에 표시합니다.
     */
    val gaitMetrics: StateFlow<GaitMetrics>

    /**
     * 운동 시간(초)
     */
    val elapsedTime: StateFlow<Long>

    /**
     * 남은 운동 시간(초)
     */
    val remainingTime: StateFlow<Long>

    /**
     * 실시간 그래프를 그리기 위한 원본 데이터 스트림.
     * 노이즈가 필터링되고, 그래프 표시에 적합한 크기(예: 100개)로 항상 유지되는 데이터 리스트를 방출(emit)합니다.
     */
    val rawGaitStream: Flow<List<Float>>

    /**
     * Median, IQR 그래프를 그리기 위한 데이터 스트림
     */
    val leftStatStream: Flow<List<Stats>>
    val rightStatStream: Flow<List<Stats>>

    /**
     * 인덱스 워킹 실패 이벤트 스트림.
     * 지정된 걸음 수를 채웠으나 양발의 압력 차이가 임계값보다 낮아 분석에 실패했을 때 방출(emit)됩니다.
     * UI는 이 이벤트를 구독하여 '재시도 안내(더 세게 밟아주세요)'를 표시하고 진행률을 초기화해야 합니다.
     */
    val indexingFailEvent: SharedFlow<Unit>

    /**
     * 인덱스 워킹 성공 이벤트 스트림.
     * 지정된 걸음 수를 채우고, 양발의 압력 차이가 충분하여 인덱싱이 성공적으로 완료되었을 때 방출(emit)됩니다.
     * UI는 이 이벤트를 구독하여 인덱스 워킹 화면을 종료하고 실시간 운동 화면으로 전환해야 합니다.
     */
    val indexingSuccessEvent: SharedFlow<Unit>

    /** 분석 세션을 시작합니다. */
    fun start(
        exerciseInfo: ExerciseInfo,
        onExerciseFinished: () -> Unit,
        startIndexingImmediately: Boolean = true
    )

    /** * 인덱스 워킹을 명시적으로 시작하거나, 재시도할 때 호출합니다.
     * * [사용 시점]
     * 1. [start] 함수 호출 시 [startIndexingImmediately]를 false로 설정한 경우 (예: 10초 워밍업 후 시작).
     * 2. 인덱스 워킹 실패([indexingFailEvent]) 후 재측정을 위해 분석기를 완전히 초기화하고 다시 시작할 때.
     * * @param startExerciseTimerWithDelay true 설정 시 운동 타이머를 2초 지연 후 시작합니다.
     */
    fun startIndexing(exerciseInfo: ExerciseInfo, startExerciseTimerWithDelay: Boolean = false)

    /**
     * 분석 세션을 중지하고 최종 분석 결과를 반환합니다.
     * @return 최종 GaitMetrics 객체
     */
    fun stop(): GaitMetrics

    /**
     * 운동중 초기화로 Median, IQR과 같은 분석만을 초기화합니다.
     */
    fun reset()
}

